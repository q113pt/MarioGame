go
use [gamemario]
go
set ansi_nulls on
go
set quoted_identifier on
go
create table Mon
(
	MaMon int not null,
	TenMon nvarchar(200) not null,
	Constraint MON_PK primary key(MaMon)
)
go
set ansi_nulls on
go
set quoted_identifier on
go
create table CauHoi
(
	NoiDung nvarchar(3000) not null,
	Lop int not null,
	Mon int not null,
	DA1 nvarchar(500) not null,
	DA2 nvarchar(500) not null,
	DA3 nvarchar(500) not null,
	DA4 nvarchar(500) not null,
	DA char not null
)
go
alter table CauHoi
add constraint FK_CAUHOI_MON foreign key(Mon) references Mon(MaMon);