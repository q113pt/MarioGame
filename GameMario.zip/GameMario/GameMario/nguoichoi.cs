﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameMario
{
	public class nguoichoi
	{
		//public string skin;
		public int mon { get; set; }
		public int mang
		{
			get; set;
		}
		public int diem
		{
			get; set;
		}
		public nguoichoi( int mon)
		{
			this.mon = mon;
			this.diem = 0;
			this.mang = 3;
		}
	}
}
