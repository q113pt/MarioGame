﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using GameMario;

namespace GameMario
{
    public class MonBus
    {
        public string id { get; set; }
        public string Ten { get; set; }
        public static List<MonBus> LayDSMon()
        {
            DataTable dt = MonDB.LayDSMon();
            List<MonBus> list = new List<MonBus>();
            foreach (DataRow dr in dt.Rows)
            {
                MonBus item = new MonBus();
                item.id = Convert.ToString(dr["MaMon"]).Trim();
                item.Ten = Convert.ToString(dr["TenMon"]).Trim();
                list.Add(item);
            }
            return list;
        }
        public override string ToString()
        {
            return this.Ten;
        }
    }
}
